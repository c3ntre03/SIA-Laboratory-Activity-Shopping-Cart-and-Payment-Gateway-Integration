<?php
require __DIR__ . '/config.php';

function finish(string $title, string $message): never {
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title><body style="font:16px Arial;max-width:800px;margin:40px auto">';
    echo '<h1>' . htmlspecialchars($title) . '</h1><p>' . htmlspecialchars($message) . '</p><p><a href="index.php">Store</a> | <a href="cart.php">Cart</a> | <a href="orders.php">Orders</a></p></body></html>';
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: cart.php'); exit; }

$customer = trim((string)($_POST['customer_name'] ?? ''));
$method = (string)($_POST['payment_method'] ?? 'CARD');
if ($customer === '') finish('Missing information', 'Enter a customer name.');
if (!in_array($method, ['CARD','EWALLET','BANK'], true)) $method = 'CARD';

$cart = $_SESSION['cart'] ?? [];
if (!$cart) finish('Empty cart', 'Add an item before checkout.');

$pdo = cart_db();
$ids = array_map('intval', array_keys($cart));
$marks = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT id,name,price,stock FROM products WHERE id IN ($marks)");
$stmt->execute($ids);
$products = $stmt->fetchAll();
$total = 0.0; $validItems = [];
foreach ($products as $p) {
    $qty = min((int)$cart[$p['id']], (int)$p['stock']);
    if ($qty > 0) {
        $total += $qty * (float)$p['price'];
        $validItems[] = ['product'=>$p,'qty'=>$qty];
    }
}
if (!$validItems || $total <= 0) finish('Checkout error', 'No valid items were found.');

/* Persist order before calling the independent payment service. */
$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("INSERT INTO orders (customer_name,total_amount,status) VALUES (?,?,'PENDING_PAYMENT')");
    $stmt->execute([$customer, number_format($total,2,'.','')]);
    $orderId = (int)$pdo->lastInsertId();
    $itemStmt = $pdo->prepare('INSERT INTO order_items (order_id,product_id,product_name,quantity,unit_price) VALUES (?,?,?,?,?)');
    foreach ($validItems as $i) {
        $itemStmt->execute([$orderId,$i['product']['id'],$i['product']['name'],$i['qty'],$i['product']['price']]);
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    finish('Order error', 'Could not save the order.');
}



/*
 * STUDENT TASK: Integrate the shopping cart with the
 * independent payment gateway.
 *
 * Requirements:
 * 1. Prepare the payment request payload.
 * 2. Send an HTTP POST request with JSON using PHP cURL.
 * 3. Handle the gateway's HTTP response.
 * 4. Validate the response and match the order ID.
 * 5. Handle SUCCESS, FAILED, and PENDING outcomes.
 * 6. Handle timeouts and invalid responses safely.
 * 7. Save the gateway transaction ID and update the
 *    order status in the shopping cart database.
 * 8. Prevent duplicate payment requests using an
 *    idempotency key.
 *
 * Read payment-gateway/README-API.md for the API contract.
 */

// Build the request from the order that was just committed to shopping_cart_db.
// The stable key is reused for retries of this same logical order.
$apiUrl = 'http://localhost/payment-gateway/api/payments.php';
$idempotencyKey = 'cart-order-' . $orderId;

// Re-read the persisted order values rather than trusting browser-supplied totals.
$orderStmt = $pdo->prepare('SELECT id, customer_name, total_amount, status FROM orders WHERE id = ?');
$orderStmt->execute([$orderId]);
$order = $orderStmt->fetch();
if (!$order) {
    finish('Order saved; payment not started', 'The order could not be reloaded. Check Order History before retrying.');
}

$payload = [
    'order_id' => (int)$order['id'],
    'amount' => (float)$order['total_amount'],
    'customer_name' => (string)$order['customer_name'],
    'payment_method' => $method,
    'idempotency_key' => $idempotencyKey,
];

// Optional server-side test switch for this classroom simulator only.
// Set PAYMENT_GATEWAY_SIMULATED_OUTCOME to SUCCESS, FAILED, or PENDING to test.
// Do not expose this setting to customers or use it in a real payment system.
$testOutcome = strtoupper(trim((string)getenv('PAYMENT_GATEWAY_SIMULATED_OUTCOME')));
if (in_array($testOutcome, ['SUCCESS', 'FAILED', 'PENDING'], true)) {
    $payload['outcome'] = $testOutcome;
}

$jsonPayload = json_encode($payload, JSON_UNESCAPED_SLASHES);
if ($jsonPayload === false) {
    $update = $pdo->prepare("UPDATE orders SET status = 'INTEGRATION_ERROR' WHERE id = ?");
    $update->execute([$orderId]);
    finish('Payment could not be started', 'The payment request could not be encoded. Check Order History before trying again.');
}

$ch = curl_init($apiUrl);
if ($ch === false) {
    $update = $pdo->prepare("UPDATE orders SET status = 'INTEGRATION_ERROR' WHERE id = ?");
    $update->execute([$orderId]);
    finish('Payment service unavailable', 'The payment request could not be initialized. Check Order History before retrying.');
}

curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $jsonPayload,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Accept: application/json',
        'Idempotency-Key: ' . $idempotencyKey,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 15,
]);
$responseBody = curl_exec($ch);
$curlError = curl_error($ch);
$curlErrno = curl_errno($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// A transport failure is ambiguous: the gateway may have recorded the payment.
// Keep the order pending and reuse the same idempotency key for any retry.
if ($responseBody === false || $curlErrno !== 0) {
    $update = $pdo->prepare("UPDATE orders SET status = 'PAYMENT_PENDING' WHERE id = ?");
    $update->execute([$orderId]);
    error_log('Payment gateway transport error for order ' . $orderId . ': ' . $curlError);
    finish('Payment status not confirmed', 'The payment service did not return a reliable response. The order remains pending. Check Order History and verify the payment before attempting again.');
}

$decoded = json_decode($responseBody, true);
if ($httpCode < 200 || $httpCode >= 300 || !is_array($decoded)) {
    // A non-success HTTP response or malformed body is not proof of a declined payment.
    $update = $pdo->prepare("UPDATE orders SET status = 'INTEGRATION_ERROR' WHERE id = ?");
    $update->execute([$orderId]);
    error_log('Payment gateway HTTP/JSON error for order ' . $orderId . '; HTTP ' . $httpCode);
    finish('Payment status could not be confirmed', 'The gateway returned an HTTP or response-format error. Check Order History and verify the payment before retrying.');
}

// Validate the response against this order before allowing it to change order state.
$responseOrderId = filter_var($decoded['order_id'] ?? null, FILTER_VALIDATE_INT);
$responseAmount = filter_var($decoded['amount'] ?? null, FILTER_VALIDATE_FLOAT);
$status = strtoupper(trim((string)($decoded['status'] ?? '')));
$transactionId = trim((string)($decoded['transaction_id'] ?? ''));
$gatewayAccepted = ($decoded['success'] ?? false) === true;
$validStatuses = ['SUCCESS', 'FAILED', 'PENDING'];

if (!$gatewayAccepted || $responseOrderId !== (int)$orderId
    || $responseAmount === false
    || abs((float)$responseAmount - (float)$order['total_amount']) > 0.009
    || !in_array($status, $validStatuses, true)
    || $transactionId === '' || strlen($transactionId) > 80) {
    $update = $pdo->prepare("UPDATE orders SET status = 'INTEGRATION_ERROR' WHERE id = ?");
    $update->execute([$orderId]);
    error_log('Invalid or mismatched payment response for order ' . $orderId);
    finish('Payment status could not be confirmed', 'The gateway response was missing required information or did not match this order. Check Order History and verify the payment before retrying.');
}

$statusMap = [
    'SUCCESS' => 'PAID',
    'FAILED' => 'PAYMENT_FAILED',
    'PENDING' => 'PAYMENT_PENDING',
];
$cartStatus = $statusMap[$status];

// Persist only against the exact order created above, using a prepared statement.
$update = $pdo->prepare('UPDATE orders SET status = ?, gateway_transaction_id = ? WHERE id = ?');
$update->execute([$cartStatus, $transactionId, $orderId]);
if ($update->rowCount() === 0) {
    // A no-op update can have rowCount zero when values already match; verify the saved row.
    $verify = $pdo->prepare('SELECT status, gateway_transaction_id FROM orders WHERE id = ?');
    $verify->execute([$orderId]);
    $saved = $verify->fetch();
    if (!$saved || $saved['status'] !== $cartStatus || $saved['gateway_transaction_id'] !== $transactionId) {
        finish('Payment received; order update needs attention', 'The gateway returned a transaction, but the order status could not be verified. Check Order History before retrying.');
    }
}

if ($status === 'SUCCESS') {
    unset($_SESSION['cart']);
    finish('Payment successful', 'Your payment was confirmed. Order #' . $orderId . ' is marked as paid. Transaction: ' . $transactionId);
}
if ($status === 'FAILED') {
    finish('Payment failed', 'The gateway confirmed that payment failed for order #' . $orderId . '. Transaction: ' . $transactionId . '. You may review the order before trying again.');
}
finish('Payment pending', 'Payment for order #' . $orderId . ' is awaiting confirmation. Transaction: ' . $transactionId . '. Check Order History before attempting payment again.');
